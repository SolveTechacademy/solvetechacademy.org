<?php
session_start();

require_once '../../config/auth.php';
require_once '../../config/database.php';

if (!isset($_SESSION['student_login'])) {
    header("Location: ../../login.php");
    exit();
}

$student_db_id = $_SESSION['student_db_id'];

$stmt = $pdo->prepare("
SELECT *
FROM students
WHERE id = ?
LIMIT 1
");

$stmt->execute([$student_db_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    session_destroy();
    header("Location: ../../login.php");
    exit();
}

if (strcasecmp(trim($student['status']), 'Active') !== 0) {
    session_destroy();
    $_SESSION['error'] = "Your account is awaiting approval.";
    header("Location: ../../login.php");
    exit();
}

$quizQuery = $pdo->prepare("
SELECT
    q.id,
    q.title,
    q.description,
    q.pass_mark,
    q.duration,
    q.attempts,
    c.course_title,
    cm.module_title,

    (
        SELECT COUNT(*)
        FROM quiz_attempts qa
        WHERE qa.quiz_id=q.id
        AND qa.student_id=?
    ) AS attempts_used

FROM registrations r

INNER JOIN courses c
ON c.id=r.course_id

INNER JOIN course_modules cm
ON cm.course_id=c.id

INNER JOIN quizzes q
ON q.module_id=cm.id

WHERE
r.student_id=?
AND r.approval_status='Approved'
AND q.status='Active'

ORDER BY
c.course_title,
cm.module_order,
q.title
");

$quizQuery->execute([
    $student_db_id,
    $student_db_id
]);

$quizzes = $quizQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>My Quizzes</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f5f7fb;
}

.card{
    border:none;
    border-radius:12px;
}

.navbar{
    background:#0d6efd;
}

.navbar-brand{
    color:#fff!important;
    font-weight:bold;
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg">

<div class="container">

<a class="navbar-brand">
SolveTech Academy Student Portal
</a>

<div>

<a href="../dashboard.php" class="btn btn-light">
Dashboard
</a>

<a href="../../logout.php" class="btn btn-danger">
Logout
</a>

</div>

</div>

</nav>

<div class="container mt-4">

<div class="card shadow">

<div class="card-header bg-primary text-white">

<h4 class="mb-0">
My Available Quizzes
</h4>

</div>

<div class="card-body">

<?php if(count($quizzes)==0){ ?>

<div class="alert alert-info mb-0">
No quizzes are currently available.
</div>

<?php } else { ?>

<table class="table table-bordered table-hover align-middle">

<thead class="table-light">

<tr>

<th>Course</th>
<th>Module</th>
<th>Quiz</th>
<th>Duration</th>
<th>Pass Mark</th>
<th>Attempts</th>
<th width="150">Action</th>

</tr>

</thead>

<tbody>

<?php foreach($quizzes as $quiz){ ?>

<tr>

<td><?= htmlspecialchars($quiz['course_title']) ?></td>

<td><?= htmlspecialchars($quiz['module_title']) ?></td>

<td>

<strong><?= htmlspecialchars($quiz['title']) ?></strong>

<?php if(!empty($quiz['description'])){ ?>

<br>

<small class="text-muted">

<?= htmlspecialchars($quiz['description']) ?>

</small>

<?php } ?>

</td>

<td>

<?= (int)$quiz['duration'] ?> mins

</td>

<td>

<?= (int)$quiz['pass_mark'] ?>%

</td>

<td>

<?= (int)$quiz['attempts_used'] ?>

/

<?= (int)$quiz['attempts'] ?>

</td>

<td>

<?php if($quiz['attempts_used'] >= $quiz['attempts']){ ?>

<button class="btn btn-secondary btn-sm w-100" disabled>

Attempts Exhausted

</button>

<?php }else{ ?>

<a
href="take.php?id=<?= $quiz['id'] ?>"
class="btn btn-success btn-sm w-100">

Start Quiz

</a>

<?php } ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

<?php } ?>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>